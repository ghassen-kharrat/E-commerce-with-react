import React from 'react';
import { useParams } from 'react-router-dom';
import { useNavigate } from 'react-router-dom';

function ListProducts({ getCurrentProdAndChangeView, data, handelDeleteProduct }) {
  console.log("data in list", data);
// console.log("getCurrentProdAndChangeView",getCurrentProdAndChangeView);
const navigate = useNavigate();
const handleNavigation = () => {
    navigate('/update'); 
  };
  return (
    <div className="container mt-4">
      {data && data.length > 0 ? (
        <div className="row">
          {data.map((element) => (
            <div key={element.id} className="col-md-4 mb-4">
                {}
              <div className="card" style={{ width: "18rem" }}>
                <img
                  src={element.imageUrl}
                  className="card-img-top"
                  alt={element.name }
                  style={{ height: "200px", objectFit: "cover" }}
                />
                <div className="card-body">
                  <h5 className="card-title">{element.name}</h5>
                  <p className="card-text">Price: TND{element.price}</p>
                  <p className="card-text">Available Quantity: {element.quantity}</p>
                  <button
                    onClick={() => handelDeleteProduct(element.id)}
                    type="button"
                    className="btn btn-danger me-2"
                  >
                    Delete
                  </button>
                  <button
                    onClick={() => {getCurrentProdAndChangeView(element)
                        // window.location.href = "update"
                        handleNavigation()
                    }}
                    type="button"
                    className="btn btn-primary"
                  >
                    Update
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <p className="text-center">No products available. Please add a product.</p>
      )}
    </div>
  );
}

export default ListProducts;
