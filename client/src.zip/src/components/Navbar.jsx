import React,{useState} from 'react';
import { Link, useNavigate } from 'react-router-dom';

function Navbar({ logout,setSearchTerm }) {
  const isAuthenticated = !!localStorage.getItem("user");
  const navigate = useNavigate();

  const handleLogout = () => {
    logout(); // Call the logout function passed as a prop
    navigate("/signup"); // Redirect to the signup page
  };
<input onChange={(e)=>(setSearch(e.target.value.toLowerCase()))}></input>
  return (
    <nav>
      <ul>
        {isAuthenticated ? (
          <>
            <li><Link to="/home">Home</Link></li>
            <li><Link to="/add">Add Product</Link></li>
            <li>
              <button onClick={handleLogout} style={{ border: 'none', background: 'none', color: 'blue', cursor: 'pointer' }}>
                Logout
              </button>
            </li>
            <li>
              <input
                type="text"
                placeholder="Search products..."
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </li>
          </>
        ) : (
          <li><Link to="/signup">Sign Up / Login</Link></li>
        )}
      </ul>
    </nav>
  );
}

export default Navbar;
