import React from 'react'
function Search({ products, ktibaserach }) {
    const filteredProducts = products.filter((product) =>{
        return(
      product.name.toLowerCase().includes(ktibaserach.toLowerCase()) ||  product.price.toString().includes(ktibaserach.toLowerCase()))
});
  
    return (
      <div>
        {filteredProducts.map((product) => (
          <div key={product.id}>
            <h1>{product.name}</h1>
            <img style={{ width: "100px" }} src={product.imageUrl} alt={product.name} />
            <p>{product.price}</p>
          </div>
        ))}
      </div>
    );
  }
  
  export default Search;
  
